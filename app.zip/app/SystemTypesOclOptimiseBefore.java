package app;

import java.util.Date;
import java.util.List;
import java.util.ArrayList;
import java.util.Map;
import java.util.HashMap;
import java.util.TreeMap;
import java.util.Set;
import java.util.TreeSet;
import java.util.HashSet;
import java.util.Collection;
import java.util.Collections;


import java.util.function.Predicate;
import java.util.function.Function;


public interface SystemTypes
{
  public class Ocl
  { 


  public static <T> HashSet<T> copySet(Collection<T> s)
  { HashSet<T> result = new HashSet<T>();
    result.addAll(s);
    return result;
  }

  public static <T> TreeSet<T> copySortedSet(Collection<T> s)
  { TreeSet<T> result = new TreeSet<T>();
    result.addAll(s);
    return result;
  }

  public static <T> ArrayList<T> copySequence(Collection<T> s)
  { ArrayList<T> result = new ArrayList<T>();
    result.addAll(s); 
    return result; 
  }

  public static <K,T> HashMap<K,T> copyMap(Map<K,T> s)
  { HashMap<K,T> result = new HashMap<K,T>();
    result.putAll(s);
    return result;
  }

  public static <T> ArrayList<T> sequenceRange(T[] arr, int n)
  { ArrayList<T> res = new ArrayList<T>();
    for (int i = 0; i < n; i++) 
    { res.add(arr[i]); } 
    return res;  
  }

  public static int sequenceCompare(List sq1, List sq2)
  { int res = 0;
    for (int i = 0; i < sq1.size() && i < sq2.size(); i++)
    { Object elem1 = sq1.get(i);
      if (((Comparable) elem1).compareTo(sq2.get(i)) < 0)
      { return -1; }
      else if (((Comparable) elem1).compareTo(sq2.get(i)) > 0)
      { return 1; }
    }

    if (sq1.size() > sq2.size())
    { return 1; }
    if (sq2.size() > sq1.size())
    { return -1; }
    return res;
  }

  public static <S,T> T iterate(Collection<S> _s, T initialValue, Function<S,Function<T,T>> _f)
  { T acc = initialValue; 
    for (S _x : _s) 
    { acc = _f.apply(_x).apply(acc); }
    return acc; 
  } 


    public static long getTime()
    { java.util.Date d = new java.util.Date();
      return d.getTime();
    }

    public static double roundN(double x, int n)
    { if (n == 0) 
      { return Math.round(x); }
      double y = x*Math.pow(10,n); 
      return Math.round(y)/Math.pow(10,n);
    }

    public static double truncateN(double x, int n)
    { if (n < 0) 
      { return (int) x; }
      double y = x*Math.pow(10,n); 
      return ((int) y)/Math.pow(10,n);
    }


  public static ArrayList<Integer> select_0(List<Integer> _l)
  { // implements: pre_sq2->select( x | x * x > 100 )
    ArrayList<Integer> _results_0 = new ArrayList<Integer>();
    for (int _i = 0; _i < _l.size(); _i++)
    { int x = ((Integer) _l.get(_i)).intValue();
      if (x * x > 100)
      { _results_0.add(x); }
    }
    return _results_0;
  }

  public static HashSet<Integer> select_0(HashSet<Integer> _l)
  { // implements: pre_sq2->select( x | x * x > 100 )
    HashSet<Integer> _results_0 = new HashSet<Integer>();
    for (Integer _i : _l)
    { int x = ((Integer) _i).intValue();
      if (x * x > 100)
      { _results_0.add(x); }
    }
    return _results_0;
  }

  public static TreeSet<Integer> select_0(TreeSet<Integer> _l)
  { TreeSet<Integer> _results_0 = new TreeSet<Integer>();
    for (Integer _i : _l)
    { int x = ((Integer) _i).intValue();
      if (x * x > 100)
      { _results_0.add(x); }
    }
    return _results_0;
  }

  public static HashSet<Integer> select_0(Set<Integer> _l)
  { // implements: pre_sq2->select( x | x * x > 100 )
    HashSet<Integer> _results_0 = new HashSet<Integer>();
    for (Integer _i : _l)
    { int x = ((Integer) _i).intValue();
      if (x * x > 100)
      { _results_0.add(x); }
    }
    return _results_0;
  }

  public static ArrayList<Integer> select_1(List<Integer> _l)
  { // implements: pre_sq2->select( x | x * x > 100 )->select( y | y * y < 1000 )
    ArrayList<Integer> _results_1 = new ArrayList<Integer>();
    for (int _i = 0; _i < _l.size(); _i++)
    { int y = ((Integer) _l.get(_i)).intValue();
      if (y * y < 1000)
      { _results_1.add(y); }
    }
    return _results_1;
  }

  public static HashSet<Integer> select_1(HashSet<Integer> _l)
  { // implements: Ocl.select_0(pre_sq2)->select( y | y * y < 1000 )
    HashSet<Integer> _results_1 = new HashSet<Integer>();
    for (Integer _i : _l)
    { int y = ((Integer) _i).intValue();
      if (y * y < 1000)
      { _results_1.add(y); }
    }
    return _results_1;
  }

  public static TreeSet<Integer> select_1(TreeSet<Integer> _l)
  { TreeSet<Integer> _results_1 = new TreeSet<Integer>();
    for (Integer _i : _l)
    { int y = ((Integer) _i).intValue();
      if (y * y < 1000)
      { _results_1.add(y); }
    }
    return _results_1;
  }

  public static HashSet<Integer> select_1(Set<Integer> _l)
  { // implements: Ocl.select_0(pre_sq2)->select( y | y * y < 1000 )
    HashSet<Integer> _results_1 = new HashSet<Integer>();
    for (Integer _i : _l)
    { int y = ((Integer) _i).intValue();
      if (y * y < 1000)
      { _results_1.add(y); }
    }
    return _results_1;
  }

  public static ArrayList<Integer> select_2(List<Integer> _l)
  { // implements: sq->select( x | x*x > 50 )
    ArrayList<Integer> _results_2 = new ArrayList<Integer>();
    for (int _i = 0; _i < _l.size(); _i++)
    { int x = ((Integer) _l.get(_i)).intValue();
      if (x*x > 50)
      { _results_2.add(x); }
    }
    return _results_2;
  }

  public static HashSet<Integer> select_2(HashSet<Integer> _l)
  { // implements: sq->select( x | x > 0 )
    HashSet<Integer> _results_2 = new HashSet<Integer>();
    for (Integer _i : _l)
    { int x = ((Integer) _i).intValue();
      if (x > 0)
      { _results_2.add(x); }
    }
    return _results_2;
  }

  public static TreeSet<Integer> select_2(TreeSet<Integer> _l)
  { TreeSet<Integer> _results_2 = new TreeSet<Integer>();
    for (Integer _i : _l)
    { int x = ((Integer) _i).intValue();
      if (x > 0)
      { _results_2.add(x); }
    }
    return _results_2;
  }

  public static HashSet<Integer> select_2(Set<Integer> _l)
  { // implements: sq->select( x | x > 0 )
    HashSet<Integer> _results_2 = new HashSet<Integer>();
    for (Integer _i : _l)
    { int x = ((Integer) _i).intValue();
      if (x > 0)
      { _results_2.add(x); }
    }
    return _results_2;
  }








  public static <T,R> HashMap<T,R> singletonMap(T x, R y)
  { HashMap<T,R> res = new HashMap<T,R>();
    res.put(x,y); 
    return res; 
  }

  public static <T,R> TreeMap<T,R> singletonSortedMap(T x, R y)
  { TreeMap<T,R> res = new TreeMap<T,R>();
    res.put(x,y); 
    return res; 
  }

    public static <T> HashSet<T> addSet(HashSet<T> s, T x)
    { if (x != null) { s.add(x); }
      return s; }

    public static HashSet<Integer> addSet(HashSet<Integer> s, int x)
    { s.add(new Integer(x));
      return s; }

    public static HashSet<Double> addSet(HashSet<Double> s, double x)
    { s.add(new Double(x));
      return s; }

    public static HashSet<Long> addSet(HashSet<Long> s, long x)
    { s.add(new Long(x));
      return s; }

    public static HashSet<Boolean> addSet(HashSet<Boolean> s, boolean x)
    { s.add(new Boolean(x));
      return s; }


    public static <T> TreeSet<T> addSet(TreeSet<T> s, T x)
    { if (x != null) { s.add(x); }
      return s; }

    public static TreeSet<Integer> addSet(TreeSet<Integer> s, int x)
    { s.add(new Integer(x));
      return s; }

    public static TreeSet<Double> addSet(TreeSet<Double> s, double x)
    { s.add(new Double(x));
      return s; }

    public static TreeSet<Long> addSet(TreeSet<Long> s, long x)
    { s.add(new Long(x));
      return s; }

    public static TreeSet<Boolean> addSet(TreeSet<Boolean> s, boolean x)
    { s.add(new Boolean(x));
      return s; }

    public static <T> ArrayList<T> addSequence(ArrayList<T> s, Object x)
    { if (x != null) { s.add((T) x); }
      return s;
    }

    public static <T extends Comparable<T>> SortedSequence<T> addSequence(SortedSequence<T> s, T x)
    { if (x != null) { s.add(x); }
      return s; }

    public static ArrayList<Integer> addSequence(ArrayList<Integer> s, int x)
    { s.add(new Integer(x));
      return s; }

    public static ArrayList<Double> addSequence(ArrayList<Double> s, double x)
    { s.add(new Double(x));
      return s; }

    public static ArrayList<Long> addSequence(ArrayList<Long> s, long x)
    { s.add(new Long(x));
      return s; }

    public static ArrayList<Boolean> addSequence(ArrayList<Boolean> s, boolean x)
    { s.add(new Boolean(x));
      return s; }


    public static <T> ArrayList<T> asSequence(Collection<T> c)
    { ArrayList res = new ArrayList<T>();
      res.addAll(c);
      return res;
    }

    public static <T> ArrayList asBag(Collection<T> c)
    { ArrayList res = new ArrayList(); 
      res.addAll(c); 
      Collections.sort(res);
      return res;
    }



    public static <T> HashSet<T> asSet(Collection<T> c)
    { HashSet<T> res = new HashSet<T>();
      res.addAll(c);
      return res;
    }

    public static <S,T> HashSet<HashMap<S,T>> asSet(Map<S,T> m)
    { ArrayList<HashMap<S,T>> res = Ocl.asSequence(m);
      return Ocl.asSet(res);
    }

    public static <T> ArrayList<T> asOrderedSet(Collection<T> c)
    { ArrayList<T> res = new ArrayList<T>();
      for (T x : c)
      { if (res.contains(x)) { }
        else 
        { res.add(x); }
      } 
      return res;
    }

    public static <S,T> ArrayList<HashMap<S,T>> asSequence(Map<S,T> m)
    { Set<Map.Entry<S,T>> ss = m.entrySet();
      ArrayList<HashMap<S,T>> res = new ArrayList<HashMap<S,T>>();
      for (Map.Entry<S,T> item : ss)
      { HashMap<S,T> maplet = new HashMap<S,T>();
        maplet.put(item.getKey(), item.getValue()); 
        res.add(maplet); 
      }  
      return res;
    }


  public static <T extends Comparable> T max(Collection<T> s)
  { ArrayList<T> slist = new ArrayList<T>();
    slist.addAll(s); 
    T result = slist.get(0);
    for (int i = 1; i < slist.size(); i++)
    { T val = slist.get(i); 
      if (0 < val.compareTo(result))
      { result = val; } 
    } 
    return result;
  } 


  public static <T extends Comparable> T min(Collection<T> s)
  { ArrayList<T> slist = new ArrayList<T>();
    slist.addAll(s); 
    T result = slist.get(0);
    for (int i = 1; i < slist.size(); i++)
    { T val = slist.get(i); 
      if (val.compareTo(result) < 0)
      { result = val; } 
    } 
    return result;
  } 


  public static <T> HashSet<T> union(HashSet a, Collection<T> b)
  { HashSet<T> res = new HashSet<T>(); 
    for (Object x : a)
    { try 
      { T y = (T) x; 
        res.add(y); 
      } catch (Exception _e) { }
    }
    res.addAll(b);
    return res;
  }

  public static <T> TreeSet<T> union(TreeSet<T> a, Collection<T> b)
  { TreeSet<T> res = (TreeSet<T>) a.clone(); 
    res.addAll(b);
    return res;
  }

  public static <T> ArrayList<T> union(ArrayList<T> a, Collection<T> b)
  { ArrayList<T> res = new ArrayList<T>(); 
    res.addAll(a); res.addAll(b);
    return res; }


  public static <T> HashSet<T> subtract(HashSet<T> a, Collection<T> b)
  { HashSet<T> res = new HashSet<T>(); 
    res.addAll(a);
    res.removeAll(b);
    return res; }

  public static <T> TreeSet<T> subtract(TreeSet<T> a, Collection<T> b)
  { TreeSet<T> res = new TreeSet<T>(); 
    res.addAll(a);
    res.removeAll(b);
    return res; }

  public static <T> ArrayList<T> subtract(ArrayList<T> a, Collection<T> b)
  { ArrayList<T> res = new ArrayList<T>(); 
    res.addAll(a);
    res.removeAll(b);
    return res; }

  public static String subtract(String a, String b)
  { String res = ""; 
    for (int i = 0; i < a.length(); i++)
    { if (b.indexOf(a.charAt(i)) < 0) { res = res + a.charAt(i); } }
    return res; }



  public static <T> HashSet<T> intersection(HashSet<T> a, Collection<T> b)
  { HashSet<T> res = new HashSet<T>(); 
    res.addAll(a);
    res.retainAll(b);
    return res; }

  public static <T> TreeSet<T> intersection(TreeSet<T> a, Collection<T> b)
  { TreeSet<T> res = new TreeSet<T>(); 
    res.addAll(a);
    res.retainAll(b);
    return res; }

  public static <T> ArrayList<T> intersection(ArrayList<T> a, Collection<T> b)
  { ArrayList<T> res = new ArrayList<T>(); 
    res.addAll(a);
    res.retainAll(b);
    return res; }



  public static <T> Set<T> symmetricDifference(Collection<T> a, Collection<T> b)
  { Set<T> res = new HashSet<T>();
    for (T _a : a)
    { if (b.contains(_a)) { }
      else { res.add(_a); }
    }
    for (T _b : b)
    { if (a.contains(_b)) { }
      else { res.add(_b); }
    }
    return res;
  }



  public static <T> boolean isUnique(Collection<T> evals)
  { HashSet<T> vals = new HashSet<T>(); 
    for (T ob : evals)
    { if (vals.contains(ob)) { return false; }
      vals.add(ob);
    }
    return true;
  }


  public static long gcd(long xx, long yy)
  { long x = Math.abs(xx);
    long y = Math.abs(yy);
    while (x != 0 && y != 0)
    { long z = y; 
      y = x % y; 
      x = z;
    } 
    if (y == 0)
    { return x; }
    if (x == 0)
    { return y; }
    return 0;
  } 


  public static int sumint(Collection<Integer> a)
  { int sum = 0; 
    for (Integer x : a)
    { if (x != null) { sum += x.intValue(); }
    } 
    return sum; }

  public static double sumdouble(Collection<Double> a)
  { double sum = 0.0; 
    for (Double x : a)
    { if (x != null) { sum += x.doubleValue(); }
    } 
    return sum; }

  public static long sumlong(Collection<Long> a)
  { long sum = 0; 
    for (Long x : a)
    { if (x != null) { sum += x.longValue(); }
    } 
    return sum; }

  public static String sumString(Collection<String> a)
  { String sum = ""; 
    for (String x : a)
    { sum = sum + x; }
    return sum;  }



  public static int prdint(Collection<Integer> a)
  { int prd = 1; 
    for (Integer x : a)
    { if (x != null) { prd *= x.intValue(); }
    } 
    return prd; }

  public static double prddouble(Collection<Double> a)
  { double prd = 1; 
    for (Double x : a)
    { if (x != null) { prd *= x.doubleValue(); }
    } 
    return prd; }

  public static long prdlong(Collection<Long> a)
  { long prd = 1; 
    for (Long x : a)
    { if (x != null) { prd *= x.longValue(); }
    } 
    return prd; }



  public static <T> ArrayList<T> concatenate(Collection<T> a, Collection b)
  { ArrayList<T> res = new ArrayList<T>(); 
    res.addAll(a); 
    res.addAll(b); 
    return res;
  }

  public static ArrayList<Object> singleValueMatrix(ArrayList<Integer> sh,Object x)
  { ArrayList<Object> result;
    if ((sh).size() == 0)
    { return (new ArrayList<Object>()); }
    int n = (int) sh.get(0);
   
    if ((sh).size() == 1)
    { ArrayList<Object> _results_0 = new ArrayList<Object>();
      for (int _i = 0; _i < n; _i++)
      { _results_0.add(x); }
      return _results_0;
    }

    ArrayList<Integer> tl = Ocl.tail(sh);
    ArrayList<Object> res = (new ArrayList<Object>());
    ArrayList<ArrayList<Object>> _results_1 = new ArrayList<ArrayList<Object>>();
    for (int _i = 0; _i < n; _i++)
    { _results_1.add(Ocl.singleValueMatrix(tl,x)); }
    res = Ocl.concatenate(res, _results_1);
    return res;
  }





  public static ArrayList reverse(Collection a)
  { ArrayList res = new ArrayList(); 
    res.addAll(a); Collections.reverse(res); 
    return res;
  }

  public static String reverse(String a)
  { String res = ""; 
    for (int i = a.length() - 1; i >= 0; i--)
    { res = res + a.charAt(i); } 
    return res;
  }



  public static <T> ArrayList<T> front(ArrayList<T> a)
  { ArrayList<T> res = new ArrayList<T>(); 
    for (int i = 0; i < a.size() - 1; i++)
    { res.add(a.get(i)); } 
    return res;
  }

  public static <T> HashSet<T> front(HashSet<T> a)
  { HashSet<T> res = new HashSet<T>();
    T lst = null;
    for (T x : a)
    { res.add(x); 
      lst = x; 
    } 
    res.remove(lst);
    return res; 
  }

  public static <T> TreeSet<T> front(TreeSet<T> a)
  { TreeSet<T> res = new TreeSet<T>();
    T lst = null;
    for (T x : a)
    { res.add(x); 
      lst = x; 
    } 
    res.remove(lst);
    return res; 
  }



  public static <T> ArrayList<T> tail(ArrayList<T> a)
  { ArrayList<T> res = new ArrayList<T>(); 
    for (int i = 1; i < a.size(); i++)
    { res.add(a.get(i)); } 
    return res;
  }

  public static <T> HashSet<T> tail(HashSet<T> a)
  { HashSet<T> res = new HashSet<T>(); 
    T fst = null; 
    for (T x : a)
    { res.add(x); 
      if (fst == null) { fst = x; }
    } 
    res.remove(fst);
    return res; 
  }

  public static <T> TreeSet<T> tail(TreeSet<T> a)
  { TreeSet<T> res = new TreeSet<T>(); 
    T fst = null; 
    for (T x : a)
    { res.add(x); 
      if (fst == null) { fst = x; }
    } 
    res.remove(fst);
    return res; 
  }



  public static <T> TreeSet<T> sortSet(HashSet<T> col)
  { TreeSet<T> res = new TreeSet<T>();
    res.addAll(col); 
    return res; 
  }

  public static ArrayList sort(Collection a)
  { ArrayList res = new ArrayList();
    res.addAll(a);
    Collections.sort(res);
    return res;
  }



  public static <T> ArrayList<T> sortedBy(final ArrayList<T> a, ArrayList<?> f)
  { int i = a.size()-1;
    if (i < 0) { return a; } 

    if (f.get(i) instanceof Comparable)
    { java.util.Map<T,Comparable> f_map = new java.util.HashMap<T,Comparable>();
      for (int j = 0; j < a.size(); j++)
      { f_map.put(a.get(j), (Comparable) f.get(j)); }
      return mergeSort(a,f_map,0,i);
    } 

    if (f.get(i) instanceof List)
    { java.util.Map<T,List> list_map = new java.util.HashMap<T,List>();
      for (int j = 0; j < a.size(); j++)
      { list_map.put(a.get(j), (List) f.get(j)); }
      return mergeSortSequence(a, list_map, 0, i);
    } 

    return a;
  }

  static <T> ArrayList<T> mergeSort(final ArrayList<T> a, java.util.Map<T,Comparable> f, int ind1, int ind2)
  { ArrayList<T> res = new ArrayList<T>();
    if (ind1 > ind2)
    { return res; }
    if (ind1 == ind2)
    { res.add(a.get(ind1));
      return res;
    }
    if (ind2 == ind1 + 1)
    { Comparable e1 = (Comparable) f.get(a.get(ind1)); 
      Comparable e2 = (Comparable) f.get(a.get(ind2));
      if (e1.compareTo(e2) < 0) // e1 < e2
      { res.add(a.get(ind1)); res.add(a.get(ind2)); return res; }
      else 
      { res.add(a.get(ind2)); res.add(a.get(ind1)); return res; }
    }
    int mid = (ind1 + ind2)/2;
    ArrayList<T> a1;
    ArrayList<T> a2;
    if (mid == ind1)
    { a1 = new ArrayList<T>();
      a1.add(a.get(ind1));
      a2 = mergeSort(a,f,mid+1,ind2);
    }
    else
    { a1 = mergeSort(a,f,ind1,mid-1);
      a2 = mergeSort(a,f,mid,ind2);
    }
    int i = 0;
    int j = 0;
    while (i < a1.size() && j < a2.size())
    { Comparable e1 = (Comparable) f.get(a1.get(i)); 
      Comparable e2 = (Comparable) f.get(a2.get(j));
      if (e1.compareTo(e2) < 0) // e1 < e2
      { res.add(a1.get(i));
        i++; // get next e1
      } 
      else 
      { res.add(a2.get(j));
        j++; 
      } 
    } 
    if (i == a1.size())
    { for (int k = j; k < a2.size(); k++)
      { res.add(a2.get(k)); } 
    } 
    else 
    { for (int k = i; k < a1.size(); k++) 
      { res.add(a1.get(k)); } 
    } 
    return res;
  }

  static <T> ArrayList<T> mergeSortSequence(final ArrayList<T> a, java.util.Map<T,List> f, int ind1, int ind2)
  { ArrayList<T> res = new ArrayList<T>();
    if (ind1 > ind2)
    { return res; }
    if (ind1 == ind2)
    { res.add(a.get(ind1));
      return res;
    }
    if (ind2 == ind1 + 1)
    { List e1 = (List) f.get(a.get(ind1)); 
      List e2 = (List) f.get(a.get(ind2));
      if (Ocl.sequenceCompare(e1,e2) < 0) // e1 < e2
      { res.add(a.get(ind1)); res.add(a.get(ind2)); return res; }
      else 
      { res.add(a.get(ind2)); res.add(a.get(ind1)); return res; }
    }
    int mid = (ind1 + ind2)/2;
    ArrayList<T> a1;
    ArrayList<T> a2;
    if (mid == ind1)
    { a1 = new ArrayList<T>();
      a1.add(a.get(ind1));
      a2 = mergeSortSequence(a,f,mid+1,ind2);
    }
    else
    { a1 = mergeSortSequence(a,f,ind1,mid-1);
      a2 = mergeSortSequence(a,f,mid,ind2);
    }
    int i = 0;
    int j = 0;
    while (i < a1.size() && j < a2.size())
    { List e1 = (List) f.get(a1.get(i)); 
      List e2 = (List) f.get(a2.get(j));
      if (Ocl.sequenceCompare(e1,e2) < 0) // e1 < e2
      { res.add(a1.get(i));
        i++; // get next e1
      } 
      else 
      { res.add(a2.get(j));
        j++; 
      } 
    } 
    if (i == a1.size())
    { for (int k = j; k < a2.size(); k++)
      { res.add(a2.get(k)); } 
    } 
    else 
    { for (int k = i; k < a1.size(); k++) 
      { res.add(a1.get(k)); } 
    } 
    return res;
  }


  public static ArrayList<Integer> integerSubrange(int i, int j)
  { ArrayList<Integer> tmp = new ArrayList<Integer>(); 
    for (int k = i; k <= j; k++)
    { tmp.add(new Integer(k)); } 
    return tmp;
  }

  public static String subrange(String s, int i, int j)
  { int len = s.length();
    if (len == 0) { return s; }
    if (j > len) { j = len; }
    if (j < i) { return ""; }
    if (i > len) { return ""; }
    if (i < 1) { i = 1; }
    return s.substring(i-1,j);
  }

  public static String subrange(String s, long i, long j)
  { long len = s.length();
    if (len == 0) { return s; }
    if (j > len) { j = len; }
    if (j < i) { return ""; }
    if (i > len) { return ""; }
    if (i < 1) { i = 1; }
    String res = ""; 
    for (long k = i-1; k < j; k++)
    { res = res + s.charAt((int) k); } 
    return res; 
  }

  public static <T> ArrayList<T> subrange(ArrayList<T> l, int i, int j)
  { ArrayList<T> tmp = new ArrayList<T>(); 
    if (i < 0) { i = l.size() + i; }
    if (j < 0) { j = l.size() + j; }
    for (int k = i-1; k < j; k++)
    { tmp.add(l.get(k)); } 
    return tmp; 
  }



  public static <T> ArrayList<T> prepend(List<T> l, T ob)
  { ArrayList<T> res = new ArrayList<T>();
    res.add(ob);
    res.addAll(l);
    return res;
  }


  public static <T> ArrayList<T> append(List<T> l, T ob)
  { ArrayList<T> res = new ArrayList<T>();
    res.addAll(l);
    res.add(ob);
    return res;
  }


  public static <T> int count(Collection<T> l, T obj)
  { return Collections.frequency(l,obj); }

  public static int count(String s, String x)
  { int res = 0; 
    if ("".equals(s)) { return res; }
    int ind = s.indexOf(x); 
    if (ind == -1) { return res; }
    String ss = s.substring(ind+1,s.length());
    res++; 
    while (ind >= 0)
    { ind = ss.indexOf(x); 
      if (ind == -1 || ss.equals("")) { return res; }
      res++; 
      ss = ss.substring(ind+1,ss.length());
    } 
    return res;
  }



  public static ArrayList<String> characters(String str)
  { char[] _chars = str.toCharArray();
    ArrayList<String> _res = new ArrayList<String>();
    for (int i = 0; i < _chars.length; i++)
    { _res.add("" + _chars[i]); }
    return _res;
  }



    public static <T> T any(Collection<T> v)
    { for (T o : v) { return o; }
      return null;
    }


    public static <T> T first(Collection<T> v)
    { for (T o : v) { return o; }
      return null;
    }


    public static <T> T last(List<T> v)
    { if (v.size() == 0) { return null; }
      return v.get(v.size() - 1);
    }

    public static <T> T last(Set<T> v)
    { int n = v.size(); 
      if (n == 0) { return null; }
      T res = null; 
      for (T o : v) { res = o; }
      return res;
    }


    public static <T> ArrayList<List<T>> subcollections(ArrayList<T> v)
    { ArrayList<List<T>> res = new ArrayList<List<T>>();
      if (v.size() == 0)
      { res.add(new ArrayList<T>()); return res; }
      if (v.size() == 1)
      { res.add(new ArrayList<T>()); res.add(v); return res;
       }
      ArrayList<T> s = new ArrayList<T>();
      T x = v.get(0);
      s.addAll(v);
      s.remove(0);
      ArrayList<List<T>> scs = subcollections(s);
      res.addAll(scs);
      for (int i = 0; i < scs.size(); i++)
      { ArrayList<T> sc = (ArrayList<T>) scs.get(i);
        ArrayList<T> scc = new ArrayList<T>();
        scc.add(x); scc.addAll(sc); res.add(scc); 
      }
      return res;
    }

    public static <T> HashSet<Set<T>> subcollections(HashSet<T> v)
    { HashSet<Set<T>> res = new HashSet<Set<T>>();
      if (v.size() == 0) { res.add(new HashSet<T>()); return res; }
      if (v.size() == 1) { res.add(new HashSet<T>()); res.add(v); return res;
       }
      HashSet<T> s = new HashSet<T>();
      T x = null; int _i = 0;
      for (T _o : v)
      { if (_i == 0) { x = _o; _i++; }
         else { s.add(_o); }
      }
      HashSet<Set<T>> scs = subcollections(s);
      res.addAll(scs);
      for (Set<T> _obj : scs)
      { HashSet<T> sc = (HashSet<T>) _obj;
        HashSet<T> scc = new HashSet<T>();
        scc.add(x); scc.addAll(sc); res.add(scc); 
      }
      return res;
    }


  public static <T, S extends Comparable> ArrayList<T> maximalElements(List<T> s, List<S> v)
  { ArrayList<T> res = new ArrayList<T>();
    if (s.size() == 0) { return res; }
    Comparable largest = (Comparable) v.get(0);
    res.add(s.get(0));
    
    for (int i = 1; i < s.size(); i++)
    { Comparable next = (Comparable) v.get(i);
      if (largest.compareTo(next) < 0)
      { largest = next;
        res.clear();
        res.add(s.get(i));
      }
      else if (largest.compareTo(next) == 0)
      { res.add(s.get(i)); }
    }
    return res;
  }

  public static <T, S extends Comparable> TreeSet<T> maximalElements(TreeSet<T> s, List<S> v)
  { ArrayList<T> lst = new ArrayList<T>();
    lst.addAll(s); 
    ArrayList<T> lres = maximalElements(lst, v);
    TreeSet<T> res = new TreeSet<T>(); 
    res.addAll(lres); 
    return res;
  }



  public static <T, S extends Comparable> ArrayList<T> minimalElements(List<T> s, List<S> v)
  { ArrayList<T> res = new ArrayList<T>();
    if (s.size() == 0) { return res; }
    Comparable smallest = (Comparable) v.get(0);
    res.add(s.get(0));
    
    for (int i = 1; i < s.size(); i++)
    { Comparable next = (Comparable) v.get(i);
      if (next.compareTo(smallest) < 0)
      { smallest = next;
        res.clear();
        res.add(s.get(i));
      }
      else if (smallest.compareTo(next) == 0)
      { res.add(s.get(i)); }
    }
    return res;
  }

  public static <T, S extends Comparable> TreeSet<T> minimalElements(TreeSet<T> s, List<S> v)
  { ArrayList<T> lst = new ArrayList<T>();
    lst.addAll(s); 
    ArrayList<T> lres = minimalElements(lst, v);
    TreeSet<T> res = new TreeSet<T>(); 
    res.addAll(lres); 
    return res;
  }



  public static <T> HashSet<T> intersectAll(Collection<Collection<T>> se)
  { HashSet<T> res = new HashSet<T>(); 
    if (se.size() == 0) { return res; }
    res.addAll((Collection<T>) Ocl.any(se));
    for (Collection<T> _o : se)
    { res.retainAll(_o); }
    return res;
  }



  public static HashSet unionAll(Collection se)
  { HashSet res = new HashSet(); 
    for (Object _o : se)
    { res.addAll((Collection) _o); }
    return res;
  }

  public static HashMap unionAllMap(Collection se)
  { HashMap res = new HashMap(); 
    for (Object _o : se)
    { res.putAll((Map) _o); }
    return res;
  }



    public static ArrayList concatenateAll(ArrayList a)
    { ArrayList res = new ArrayList();
      for (int i = 0; i < a.size(); i++)
      { Collection r = (Collection) a.get(i);
        res.addAll(r); 
      }
      return res;
    }



  public static <T> ArrayList<T> insertAt(List<T> l, int ind, T ob)
  { ArrayList<T> res = new ArrayList<T>();
    for (int i = 0; i < ind-1 && i < l.size(); i++)
    { res.add(l.get(i)); }
    if (ind <= l.size() + 1) { res.add(ob); }
    for (int i = ind-1; i < l.size(); i++)
    { res.add(l.get(i)); }
    return res;
  }
  public static String insertAt(String l, int ind, Object ob)
  { String res = "";
    for (int i = 0; i < ind-1 && i < l.length(); i++)
    { res = res + l.charAt(i); }
    if (ind <= l.length() + 1) { res = res + ob; }
    for (int i = ind-1; i < l.length(); i++)
    { res = res + l.charAt(i); }
    return res;
  }


  public static <T> ArrayList<T> insertInto(List<T> l, int ind, List<T> ob)
  { ArrayList<T> res = new ArrayList<T>();
    for (int i = 0; i < ind-1 && i < l.size(); i++)
    { res.add(l.get(i)); }
    for (int j = 0; j < ob.size(); j++)
    { res.add(ob.get(j)); }
    for (int i = ind-1; i < l.size(); i++)
    { res.add(l.get(i)); }
    return res;
  }

  public static <T> ArrayList<T> excludingSubrange(List<T> l, int startIndex, int endIndex)
  { ArrayList<T> res = new ArrayList<T>();
    for (int i = 0; i < startIndex-1 && i < l.size(); i++)
    { res.add(l.get(i)); }
    for (int i = endIndex; i < l.size(); i++)
    { res.add(l.get(i)); }
    return res;
  }

  public static String insertInto(String l, int ind, Object ob)
  { String res = "";
    for (int i = 0; i < ind-1 && i < l.length(); i++)
    { res = res + l.charAt(i); }
    res = res + ob;
    for (int i = ind-1; i < l.length(); i++)
    { res = res + l.charAt(i); }
    return res;
  }

  public static String excludingSubrange(String l, int startIndex, int endIndex)
  { String res = "";
    for (int i = 0; i < startIndex-1 && i < l.length(); i++)
    { res = res + l.charAt(i); }
    for (int i = endIndex; i < l.length(); i++)
    { res = res + l.charAt(i); }
    return res;
  }

  public static String setSubrange(String ss, int startIndex, int endIndex, String v)
  { String res = ss;
    if (ss.length() < endIndex)
    { for (int i = ss.length()-1; i < endIndex; i++)
      { res = res + " "; }
    }
    return res.substring(0,startIndex-1) + v +
           res.substring(endIndex);  
  }



  public static <T> ArrayList<T> removeAt(List<T> l, int ind)
  { ArrayList<T> res = new ArrayList<T>();
    res.addAll(l); 
    if (ind <= res.size() && ind >= 1)
    { res.remove(ind - 1); } 
    return res;
  }

  public static String removeAt(String ss, int ind)
  { StringBuffer sb = new StringBuffer(ss); 
    if (ind <= ss.length() && ind >= 1)
    { sb.deleteCharAt(ind - 1); } 
    return sb.toString();
  }

  public static <T> ArrayList<T> removeFirst(List<T> l, T x)
  { ArrayList<T> res = new ArrayList<T>();
    res.addAll(l); 
    res.remove(x);
    return res;
  }

  public static <T> ArrayList<T> setAt(List<T> l, int ind, T val)
  { ArrayList<T> res = new ArrayList<T>();
    res.addAll(l); 
    if (ind <= res.size() && ind >= 1)
    { res.set(ind - 1,val); } 
    return res;
  }

  public static String setAt(String ss, int ind, Object val)
  { String res = ss;
    if (ind <= res.length() && ind >= 1)
    { res = ss.substring(0,ind-1); 
      res = res + val + ss.substring(ind);
    } 
    return res;
  }


 public static boolean isInteger(String str)
  { try { Integer.parseInt(str.trim()); return true; }
    catch (Exception _e) { return false; }
  }

 public static int toInt(String str)
  { /* Trim leading 0's */
    if (str == null || str.length() == 0)
    { return 0; }
    String trm = str.trim();
    while (trm.length() > 0 && trm.charAt(0) == '0')
    { trm = trm.substring(1); }
    if (trm.indexOf(".") > 0)
    { trm = trm.substring(0,trm.indexOf(".")); }
    try { int x = Integer.parseInt(trm.trim());
          return x; }
    catch (Exception _e) { return 0; }
  }

  public static int toInteger(String str)
  { if (str == null || str.length() == 0)
    { return 0; }
    String trm = str.trim();
    while (trm.length() > 0 && trm.charAt(0) == '0')
    { trm = trm.substring(1); }
    if (trm.indexOf(".") > 0)
    { trm = trm.substring(0,trm.indexOf(".")); }
    try { int x = Integer.decode(trm).intValue();
      return x; 
    }
    catch (Exception _e) { return 0; }
  }



 public static boolean isReal(String str)
  { try { double d = Double.parseDouble(str.trim()); 
          if (Double.isNaN(d)) { return false; }
          return true; }
    catch (Exception _e) { return false; }
  }

 public static double toDouble(String str)
  { try { double x = Double.parseDouble(str.trim());
          return x; }
    catch (Exception _e) { return 0; }
  }


 public static boolean isLong(String str)
  { try { Long.parseLong(str.trim()); return true; }
    catch (Exception _e) { return false; }
  }

 public static long toLong(String str)
  { try { long x = Long.parseLong(str.trim());
          return x; }
    catch (Exception _e) { return 0; }
  }


 public static String byte2char(int b)
  { try { byte[] bb = {(byte) b}; 
      return new String(bb); }
    catch (Exception _e)
    { return ""; }
  }

  public static int char2byte(String s)
  { if (s == null || s.length() == 0)
    { return -1; } 
    return (int) s.charAt(0);
  }



  public static boolean oclIsTypeOf(Object x, String E)
  { try { 
    if (x.getClass() == Class.forName(E))
    { return true; } 
    else 
    { return false; }
    } 
    catch (Exception e) { return false; }
  } 


  public static String before(String s, String sep)
  { if (sep.length() == 0) { return s; }
    int ind = s.indexOf(sep);
    if (ind < 0) { return s; }
    return s.substring(0,ind); 
  }


  public static String after(String s, String sep)
  { int ind = s.indexOf(sep);
    int seplength = sep.length();
    if (ind < 0) { return ""; }
    if (seplength == 0) { return ""; }
    return s.substring(ind + seplength, s.length()); 
  }


  public static boolean hasMatch(String str, String regex)
  { java.util.regex.Pattern patt = java.util.regex.Pattern.compile(regex);
    java.util.regex.Matcher matcher = patt.matcher(str); 
    if (matcher.find())
    { return true; }
    return false;
  }



  public static ArrayList<String> allMatches(String str, String regex)
  { java.util.regex.Pattern patt = java.util.regex.Pattern.compile(regex);
    java.util.regex.Matcher matcher = patt.matcher(str);
    ArrayList<String> res = new ArrayList<String>();
    while (matcher.find())
    { res.add(matcher.group() + ""); }
    return res; 
  }


  public static String firstMatch(String str, String regex)
  { java.util.regex.Pattern patt = java.util.regex.Pattern.compile(regex);
    java.util.regex.Matcher matcher = patt.matcher(str);
    String res = null;
    if (matcher.find())
    { res = matcher.group() + ""; }
    return res; 
  }


  public static ArrayList<String> split(String str, String delim)
  { String[] splits = str.split(delim);
    ArrayList<String> res = new ArrayList<String>();
    for (int j = 0; j < splits.length; j++)
    { if (splits[j].length() > 0) 
      { res.add(splits[j]); }
    }
    return res;
  }


  public static String replace(String str, String delim, String rep)
  { String result = "";
    String s = str + "";
    int i = (s.indexOf(delim) + 1);
    if (i == 0)
    { return s; }
    
    int sublength = delim.length();
    if (sublength == 0)
    { return s; }
    
    while (i > 0)
    { result = result + Ocl.subrange(s,1,i - 1) + rep;
      s = Ocl.subrange(s,i + delim.length(),s.length());
      i = (s.indexOf(delim) + 1);
    }
    result = result + s;
    return result;
  }


  public static String replaceAll(String str, String regex, String rep)
  { if (str == null) { return null; }
    java.util.regex.Pattern patt = java.util.regex.Pattern.compile(regex);
    java.util.regex.Matcher matcher = patt.matcher(str);
    return matcher.replaceAll(rep);
  }


  public static String replaceFirstMatch(String str, String regex, String rep)
  { if (str == null) { return null; }
    java.util.regex.Pattern patt = java.util.regex.Pattern.compile(regex);
    java.util.regex.Matcher matcher = patt.matcher(str);
    return matcher.replaceFirst(rep);
  }


  public static <D,R> boolean includesAllMap(Map<D,R> sup, Map<D,R> sub)
  { Set<D> keys = sub.keySet();
  
    for (D key : keys)
    { if (sup.containsKey(key))
      { if (sub.get(key).equals(sup.get(key)))
        {}
        else
        { return false; }
      }
      else 
      { return false; }
    }    
    return true;
  }


  public static <D,R> boolean excludesAllMap(Map<D,R> sup, Map<D,R> sub)
  { Set<D> keys = sub.keySet();
  
    for (D key : keys)
    { if (sup.containsKey(key))
      { if (sub.get(key).equals(sup.get(key)))
        { return false; }
      }
    }    
    return true;
  }


  public static <D,R> HashMap<D,R> includingMap(HashMap<D,R> m, D src, R trg)
  { HashMap<D,R> copy = new HashMap<D,R>();
    copy.putAll(m); 
    copy.put(src,trg);
    return copy;
  } 

  public static <D,R> TreeMap<D,R> includingMap(TreeMap<D,R> m, D src, R trg)
  { TreeMap<D,R> copy = (TreeMap<D,R>) m.clone();
    copy.put(src,trg);
    return copy;
  } 


  public static <D,R> HashMap<D,R> excludeAllMap(HashMap<D,R> m1, Map m2)
  { // m1 - m2
    HashMap<D,R> res = new HashMap<D,R>();
    Set<D> keys = m1.keySet(); 
  
    for (D key : keys)
    { if (m2.containsKey(key))
      { }
      else
      { res.put(key,m1.get(key)); }
    }    
    return res;
  }

  public static <D,R> TreeMap<D,R> excludeAllMap(TreeMap<D,R> m1, Map m2)
  { // m1 - m2
    TreeMap<D,R> res = new TreeMap<D,R>();
    Set<D> keys = m1.keySet(); 
  
    for (D key : keys)
    { if (m2.containsKey(key))
      { }
      else
      { res.put(key,m1.get(key)); }
    }    
    return res;
  }


  public static <D,R> HashMap<D,R> excludingMapKey(HashMap<D,R> m, D k)
  { // m - { k |-> m(k) } 
    HashMap<D,R> res = new HashMap<D,R>();
    res.putAll(m);
    res.remove(k);
    return res;
  }

  public static <D,R> TreeMap<D,R> excludingMapKey(TreeMap<D,R> m, D k)
  { // m - { k |-> m(k) } 
    TreeMap<D,R> res = (TreeMap<D,R>) m.clone();
    res.remove(k);
    return res;
  }


  public static <D,R> HashMap<D,R> excludingMapValue(HashMap<D,R> m, R v)
  { // m - { k |-> v }
    HashMap<D,R> res = new HashMap<D,R>();
    Set<D> keys = m.keySet(); 
    
    for (D key : keys)
    { if (v.equals(m.get(key)))
      { }
      else
      { res.put(key,m.get(key));  }
    }    
    return res;
  }

  public static <D,R> TreeMap<D,R> excludingMapValue(TreeMap<D,R> m, R v)
  { // m - { k |-> v }
    TreeMap<D,R> res = new TreeMap<D,R>();
    Set<D> keys = m.keySet(); 
    
    for (D key : keys)
    { if (v.equals(m.get(key)))
      { }
      else
      { res.put(key,m.get(key));  }
    }    
    return res;
  }


  public static <D,R> HashMap<D,R> unionMap(HashMap<D,R> m1, Map<D,R> m2)
  { HashMap<D,R> res = new HashMap<D,R>();
    res.putAll(m1);
    res.putAll(m2);    
    return res;
  }

  public static <D,R> TreeMap<D,R> unionMap(TreeMap<D,R> m1, Map<D,R> m2)
  { TreeMap<D,R> res = (TreeMap<D,R>) m1.clone();
    res.putAll(m2);    
    return res;
  }


  public static <D,R> HashMap<D,R> intersectionMap(HashMap<D,R> m1, Map m2)
  { HashMap<D,R> res = new HashMap<D,R>();
    Set<D> keys = m1.keySet(); 
  
    for (D key : keys)
    { if (m2.containsKey(key) && m1.get(key) != null && m1.get(key).equals(m2.get(key)))
      { res.put(key,m1.get(key));  }
    }    
    return res;
  }

  public static <D,R> TreeMap<D,R> intersectionMap(TreeMap<D,R> m1, Map m2)
  { TreeMap<D,R> res = new TreeMap<D,R>();
    Set<D> keys = m1.keySet(); 
  
    for (D key : keys)
    { if (m2.containsKey(key) && m1.get(key) != null && m1.get(key).equals(m2.get(key)))
      { res.put(key,m1.get(key));  }
    }    
    return res;
  }

  public static HashMap intersectAllMap(Collection col)
  { HashMap res = new HashMap();
    if (col.size() == 0) 
    { return res; } 

    Map m0 = (Map) Ocl.any(col);
    res.putAll(m0); 

    for (Object obj : col)
    { Map m = (Map) obj;
      res = Ocl.intersectionMap(res,m);
    }
    return res; 
  } 

  public static <D,R> HashMap<D,R> restrictMap(HashMap<D,R> m1, Collection<D> ks) 
  { Set<D> keys = new HashSet<D>();
    keys.addAll(m1.keySet());
    HashMap<D,R> res = new HashMap<D,R>();
  
    for (D key : keys)
    { if (ks.contains(key))
      { res.put(key,m1.get(key)); }
    }    
    return res;
  }

  public static <D,R> TreeMap<D,R> restrictMap(TreeMap<D,R> m1, Collection<D> ks) 
  { Set<D> keys = new HashSet<D>();
    keys.addAll(m1.keySet());
    TreeMap<D,R> res = new TreeMap<D,R>();
  
    for (D key : keys)
    { if (ks.contains(key))
      { res.put(key,m1.get(key)); }
    }    
    return res;
  }

  public static <D,R> HashMap<D,R> antirestrictMap(HashMap<D,R> m1, Collection<D> ks) 
  { Set<D> keys = new HashSet<D>();
    keys.addAll(m1.keySet());
    HashMap<D,R> res = new HashMap<D,R>();
  
    for (D key : keys)
    { if (ks.contains(key)) { }
      else 
      { res.put(key,m1.get(key)); }
    }    
    return res;
  }

  public static <D,R> TreeMap<D,R> antirestrictMap(TreeMap<D,R> m1, Collection<D> ks) 
  { Set<D> keys = new HashSet<D>();
    keys.addAll(m1.keySet());
    TreeMap<D,R> res = new TreeMap<D,R>();
  
    for (D key : keys)
    { if (ks.contains(key)) { }
      else 
      { res.put(key,m1.get(key)); }
    }    
    return res;
  }

  public static <D,R> HashMap<D,R> selectMap(HashMap<D,R> m, Predicate<R> f)
  { HashMap<D,R> result = new HashMap<D,R>();
    Set<D> keys = m.keySet();
    for (D k : keys)
    { R value = m.get(k);
      if (f.test(value))
      { result.put(k,value); }
    }
    return result;
  }

  public static <D,R> TreeMap<D,R> selectMap(TreeMap<D,R> m, Predicate<R> f)
  { TreeMap<D,R> result = new TreeMap<D,R>();
    Set<D> keys = m.keySet();
    for (D k : keys)
    { R value = m.get(k);
      if (f.test(value))
      { result.put(k,value); }
    }
    return result;
  }

  public static <D,R> HashMap<D,R> rejectMap(HashMap<D,R> m, Predicate<R> f)
  { HashMap<D,R> result = new HashMap<D,R>();
    Set<D> keys = m.keySet();
    for (D k : keys)
    { R value = m.get(k);
      if (f.test(value)) {}
      else
      { result.put(k,value); }
    }
    return result;
  }

  public static <D,R> TreeMap<D,R> rejectMap(TreeMap<D,R> m, Predicate<R> f)
  { TreeMap<D,R> result = new TreeMap<D,R>();
    Set<D> keys = m.keySet();
    for (D k : keys)
    { R value = m.get(k);
      if (f.test(value)) {}
      else
      { result.put(k,value); }
    }
    return result;
  }

  public static <D,R,T> HashMap<D,T> collectMap(Map<D,R> m, Function<R,T> _f)
  { HashMap<D,T> result = new HashMap<D,T>();
    Set<D> keys = m.keySet();
    for (D k : keys)
    { R value = m.get(k);
      result.put(k, _f.apply(value));
    }
    return result;
  }



  public static <T> T[] asReference(ArrayList sq, T[] r)
  {
    for (int i = 0; i < sq.size() && i < r.length; i++)
    { r[i] = (T) sq.get(i); }
    return r;
  }

  public static int[] resizeTo(int[] arr, int n)
  { int[] tmp = new int[n];
    for (int i = 0; i < n; i++)
    { tmp[i] = arr[i]; }
    return tmp;
  }

  public static long[] resizeTo(long[] arr, int n)
  { long[] tmp = new long[n];
    for (int i = 0; i < n; i++)
    { tmp[i] = arr[i]; }
    return tmp;
  }

  public static double[] resizeTo(double[] arr, int n)
  { double[] tmp = new double[n];
    for (int i = 0; i < n; i++)
    { tmp[i] = arr[i]; }
    return tmp;
  }

  public static boolean[] resizeTo(boolean[] arr, int n)
  { boolean[] tmp = new boolean[n];
    for (int i = 0; i < n; i++)
    { tmp[i] = arr[i]; }
    return tmp;
  }

  public static Object[] resizeTo(Object[] arr, int n)
  { Object[] tmp = new Object[n];
    for (int i = 0; i < n; i++)
    { tmp[i] = arr[i]; }
    return tmp;
  }

  public static ArrayList sequenceRange(int[] arr, int n)
  { ArrayList res = new ArrayList();
    for (int i = 0; i < n && i < arr.length; i++)
    { res.add(new Integer(arr[i])); }
    return res; 
  }

  public static ArrayList sequenceRange(long[] arr, int n)
  { ArrayList res = new ArrayList();
    for (int i = 0; i < n && i < arr.length; i++)
    { res.add(new Long(arr[i])); }
    return res; 
  }

  public static ArrayList sequenceRange(double[] arr, int n)
  { ArrayList res = new ArrayList();
    for (int i = 0; i < n && i < arr.length; i++)
    { res.add(new Double(arr[i])); }
    return res; 
  }

  public static ArrayList sequenceRange(boolean[] arr, int n)
  { ArrayList res = new ArrayList();
    for (int i = 0; i < n && i < arr.length; i++)
    { res.add(new Boolean(arr[i])); }
    return res; 
  }

  public static <T> ArrayList asSequence(T[] r)
  { ArrayList res = new ArrayList(); 
    for (int i = 0; i < r.length; i++)
    { res.add(r[i]); }
    return res;
  }


  }
}

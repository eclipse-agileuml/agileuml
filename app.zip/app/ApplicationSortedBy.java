package app; 

import java.util.*;
import java.util.HashMap;
import java.util.Collection;
import java.util.List;
import java.util.ArrayList;
import java.util.Set;
import java.util.HashSet;
import java.util.TreeSet;
import java.util.Collections;
import java.util.function.Function;
import java.io.Serializable;

class Person { static ArrayList<Person> Person_allInstances = new ArrayList<Person>();

  Person() { Person_allInstances.add(this); }

  static Person createPerson() { Person result = new Person();
    return result; }

  String name = "";
  int age = 0;
}

class CC { static ArrayList<CC> CC_allInstances = new ArrayList<CC>();

  CC() { CC_allInstances.add(this); }

  static CC createCC() { CC result = new CC();
    return result; }

  ArrayList<Person> sq = (new ArrayList());

  public ArrayList<Person> op()
  {
    ArrayList<Person> result = new ArrayList<Person>();
    result = Ocl.sortedBy(sq, Ocl.collectSequence(sq, (var1)->{ return var1.name; }));
    return result;
  }

}

class Application { 

  public static void main(String[] args)
  { Person p1 = new Person(); 
    p1.name = "Tom"; 
	
	Person p2 = new Person(); 
    p2.name = "Alice"; 
	
	Person p3 = new Person(); 
    p3.name = "Harry"; 
	
	CC cx = new CC(); 
	cx.sq.add(p1); cx.sq.add(p2); cx.sq.add(p3);
	
	ArrayList<Person> lst = cx.op(); 
	for (Person px : lst)
	{ System.out.println(px.name); }
  }
}

package app;

import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.HashMap;
import java.util.Vector;

public interface ControllerInterface
{
  public void addCC(CC oo);
    public void killCC(CC ccxx);
}


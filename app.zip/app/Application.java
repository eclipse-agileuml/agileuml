package app; 

import java.util.*;
import java.util.HashMap;
import java.util.Collection;
import java.util.List;
import java.util.ArrayList;
import java.util.Set;
import java.util.HashSet;
import java.util.TreeSet;
import java.util.Collections;
import java.util.function.Function;
import java.io.Serializable;

class CC { static ArrayList<CC> CC_allInstances = new ArrayList<CC>();

  CC() { CC_allInstances.add(this); }

  static CC createCC() { CC result = new CC();
    return result; }

  ArrayList<Integer> col = Ocl.initialiseSequence(-1,-2,3,-3,2,1,0);

  public int op1()
  {
    int result = 0;
    result = Ocl.last(Ocl.sortedBy(col, Ocl.collectSequence(col, (x)->{ return x * x; })));
    return result;
  }


  public int op2()
  {
    int result = 0;
    result = Ocl.any(Ocl.selectMaximals(col, (x)->{ return x * x; }));
    return result;
  }

}

class Application { 
  public static void main(String[] args)
  { CC xx = new CC(); 

    // 50000 for size 100000 list, etc  
    for (int i = 50000; i >= 0; i--)
	{ xx.col.add(i); xx.col.add(-i); }
	
	java.util.Date d1 = new java.util.Date(); 
	long t1 = d1.getTime(); 
	
    int res1 = xx.op1(); // sortedBy
	
	java.util.Date d2 = new java.util.Date(); 
	long t2 = d2.getTime(); 
	 
	// int res2 = xx.op2(); // selectMaximals
	
	java.util.Date d3 = new java.util.Date(); 
	long t3 = d3.getTime(); 

	// System.out.println(res1 + "   " + res2); 
	
	System.out.println("Time for sortedBy: " + (t2 - t1)); 
	System.out.println("Time for selectMaximals: " + (t3 - t2)); 
  }
}


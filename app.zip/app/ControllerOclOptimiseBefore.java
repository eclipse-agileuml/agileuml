package app;


import java.util.*;
import java.util.HashMap;
import java.util.Collection;
import java.util.List;
import java.util.ArrayList;
import java.util.Set;
import java.util.HashSet;
import java.util.TreeSet;
import java.util.Collections;
import java.lang.*;
import java.lang.reflect.*;
import java.util.StringTokenizer;
import java.io.*;

import java.util.function.Predicate;
import java.util.function.Function;

class CC
  implements SystemTypes
{
  private ArrayList<Integer> sq; // internal

  public CC()
  {
    this.sq = (new ArrayList<Integer>());

  }

  public Object clone()
  { CC result = new CC();
    result.sq = this.sq;
    return result;
  }



  public String toString()
  { String _res_ = "(CC) ";
    _res_ = _res_ + sq;
    return _res_;
  }

  public void setsq(ArrayList<Integer> sq_x) { 
    sq = sq_x;  }


  public void setsq(int _ind, int sq_x) { sq.set(_ind, sq_x);  }


    public void addsq(int sq_x)
  { sq.add(new Integer(sq_x)); }

  public void removesq(int sq_x)
  { ArrayList<Integer> _removedsq = new ArrayList<Integer>();
    _removedsq.add(new Integer(sq_x));
    sq.removeAll(_removedsq);
  }



  

    public ArrayList<Integer> getsq() { return sq; }

  

  

    public void op(int z)
  {     ArrayList<Integer> pre_sq0 = new ArrayList<Integer>();
    pre_sq0.addAll(sq);
Controller.inst().setsq(this,((pre_sq0.contains(z)) ? (pre_sq0) : (Ocl.union(pre_sq0,Ocl.addSequence(new ArrayList<Integer>(), new Integer(z))))));
  }

    public void op1()
  {     ArrayList<Integer> pre_sq1 = new ArrayList<Integer>();
    pre_sq1.addAll(sq);
Controller.inst().setsq(this,((ArrayList<Integer>) Ocl.sort(pre_sq1)));
  }

    public void op2()
  {     ArrayList<Integer> pre_sq2 = new ArrayList<Integer>();
    pre_sq2.addAll(sq);
Controller.inst().setsq(this,Ocl.select_1(Ocl.select_0(pre_sq2)));
    Controller.inst().setsq(this,Ocl.select_1(Ocl.select_0(pre_sq2)));
  }

    public int op3()
  {   int result = 0;
  
    result = ((Integer) Ocl.any(Ocl.select_2(sq))).intValue();
  
    return result;
  }



}



public class Controller implements SystemTypes
{
  ArrayList<CC> ccs = new ArrayList<CC>();
  private static Controller uniqueInstance; 


  private Controller() { } 


  public static Controller inst() 
    { if (uniqueInstance == null) 
    { uniqueInstance = new Controller(); }
    return uniqueInstance; } 


  public static void loadModel(String file)
  {
    try
    { BufferedReader br = null;
      File f = new File(file);
      try 
      { br = new BufferedReader(new FileReader(f)); }
      catch (Exception ex) 
      { System.err.println("No file: " + file); return; }
      Class cont = Class.forName("app.Controller");
      java.util.Map objectmap = new java.util.HashMap();
      while (true)
      { String line1;
        try { line1 = br.readLine(); }
        catch (Exception e)
        { return; }
        if (line1 == null)
        { return; }
        line1 = line1.trim();

        if (line1.length() == 0) { continue; }
        if (line1.startsWith("//")) { continue; }
        String left;
        String op;
        String right;
        if (line1.charAt(line1.length() - 1) == '"')
        { int eqind = line1.indexOf("="); 
          if (eqind == -1) { continue; }
          else 
          { left = line1.substring(0,eqind-1).trim();
            op = "="; 
            right = line1.substring(eqind+1,line1.length()).trim();
          }
        }
        else
        { StringTokenizer st1 = new StringTokenizer(line1);
          Vector vals1 = new Vector();
          while (st1.hasMoreTokens())
          { String val1 = st1.nextToken();
            vals1.add(val1);
          }
          if (vals1.size() < 3)
          { continue; }
          left = (String) vals1.get(0);
          op = (String) vals1.get(1);
          right = (String) vals1.get(2);
        }
        if (":".equals(op))
        { int i2 = right.indexOf(".");
          if (i2 == -1)
          { Class cl;
            try { cl = Class.forName("app." + right); }
            catch (Exception _x) { System.err.println("No entity: " + right); continue; }
            Object xinst = cl.newInstance();
            objectmap.put(left,xinst);
            Class[] cargs = new Class[] { cl };
            Method addC = null;
            try { addC = cont.getMethod("add" + right,cargs); }
            catch (Exception _xx) { System.err.println("No entity: " + right); continue; }
            if (addC == null) { continue; }
            Object[] args = new Object[] { xinst };
            addC.invoke(Controller.inst(),args);
          }
          else
          { String obj = right.substring(0,i2);
            String role = right.substring(i2+1,right.length());
            Object objinst = objectmap.get(obj); 
            if (objinst == null) 
            { System.err.println("Warning: no object " + obj); continue; }
            Object val = objectmap.get(left);
            if (val == null &&
                left.length() > 1 &&
                left.startsWith("\"") &&
                left.endsWith("\""))
            { val = left.substring(1,left.length()-1); }
            else if (val == null) 
            { continue; }
            Class objC = objinst.getClass();
            Class typeclass = val.getClass(); 
            Object[] args = new Object[] { val }; 
            Class[] settypes = new Class[] { typeclass };
            Method addrole = Controller.findMethod(objC,"add" + role);
            if (addrole != null) 
            { addrole.invoke(objinst, args); }
            else { System.err.println("Error: cannot add to " + role); }
          }
        }
        else if ("=".equals(op))
        { int i1 = left.indexOf(".");
          if (i1 == -1) 
          { continue; }
          String obj = left.substring(0,i1);
          String att = left.substring(i1+1,left.length());
          Object objinst = objectmap.get(obj); 
          if (objinst == null) 
          { System.err.println("No object: " + obj); continue; }
          Class objC = objinst.getClass();
          Class typeclass; 
          Object val; 
          if (right.charAt(0) == '"' &&
              right.charAt(right.length() - 1) == '"')
          { typeclass = String.class;
            val = right.substring(1,right.length() - 1);
          } 
          else if ("true".equals(right) || "false".equals(right))
          { typeclass = boolean.class;
            if ("true".equals(right))
            { val = new Boolean(true); }
            else
            { val = new Boolean(false); }
          }
          else 
          { val = objectmap.get(right);
            if (val != null)
            { typeclass = val.getClass(); }
            else 
            { int i;
              long l; 
              double d;
              try 
              { i = Integer.parseInt(right);
                typeclass = int.class;
                val = new Integer(i); 
              }
              catch (Exception ee)
              { try 
                { l = Long.parseLong(right);
                  typeclass = long.class;
                  val = new Long(l); 
                }
                catch (Exception eee)
                { try
                  { d = Double.parseDouble(right);
                    typeclass = double.class;
                    val = new Double(d);
                  }
                  catch (Exception ff)
                  { continue; }
                }
              }
            }
          }
          Object[] args = new Object[] { val }; 
          Class[] settypes = new Class[] { typeclass };
          Method setatt = Controller.findMethod(objC,"set" + att);
          if (setatt != null) 
          { setatt.invoke(objinst, args); }
          else { System.err.println("No attribute: " + objC.getName() + "::" + att); }
        }
      }
    } catch (Exception e) { }
  }

  public static Method findMethod(Class c, String name)
  { Method[] mets = c.getMethods(); 
    for (int i = 0; i < mets.length; i++)
    { Method m = mets[i];
      if (m.getName().equals(name))
      { return m; }
    } 
    return null;
  }


  public void checkCompleteness()
  {   }


  public void saveModel(String file)
  { File outfile = new File(file); 
    PrintWriter out; 
    try { out = new PrintWriter(new BufferedWriter(new FileWriter(outfile))); }
    catch (Exception e) { return; } 
    saveModel2(out);
  }

  public void saveModel2(PrintWriter out)
  {
    out.close(); 
  }



  public void addCC(CC oo) { ccs.add(oo); }



  public void createAllCC(ArrayList<CC> ccx)
  { for (int i = 0; i < ccx.size(); i++)
    { CC ccx_x = new CC();
      ccx.set(i,ccx_x);
      addCC(ccx_x);
    }
  }


  public CC createCC()
  { CC ccx;
    
    ccx = new CC();
    addCC(ccx);
    setsq(ccx,(new ArrayList<Integer>()));

    return ccx;
  }


public void setsq(CC ccx, int _ind, int sq_x) 
  { ccx.setsq(_ind, sq_x); }

  public void setsq(CC ccx, ArrayList<Integer> sq_x) 
  { ccx.setsq(sq_x);
    }


  public void addsq(CC ccx, int sq_x)
  { ccx.addsq(sq_x); }


  public void removesq(CC ccx, int sq_x)
  { ccx.removesq(sq_x); }



  public void op(CC ccx,int z)
  {   ccx.op(z);
   }

  public  ArrayList AllCCop(Collection<CC> ccxs,int z)
  { 
    ArrayList result = new ArrayList();
    for (Object _i : ccxs)
    { CC ccx = (CC) _i;
      op(ccx,z);
    }
    return result; 
  }

  public void op1(CC ccx)
  {   ccx.op1();
   }

  public  ArrayList AllCCop1(Collection<CC> ccxs)
  { 
    ArrayList result = new ArrayList();
    for (Object _i : ccxs)
    { CC ccx = (CC) _i;
      op1(ccx);
    }
    return result; 
  }

  public void op2(CC ccx)
  {   ccx.op2();
   }

  public  ArrayList AllCCop2(Collection<CC> ccxs)
  { 
    ArrayList result = new ArrayList();
    for (Object _i : ccxs)
    { CC ccx = (CC) _i;
      op2(ccx);
    }
    return result; 
  }

  public  ArrayList<Integer> AllCCop3(Collection<CC> ccxs)
  { 
    ArrayList<Integer> result = new ArrayList<Integer>();
    for (Object _i : ccxs)
    { CC ccx = (CC) _i;
      result.add(new Integer(ccx.op3()));
    }
    return result; 
  }



  public void killAllCC(Collection<CC> ccxx)
  { for (Object _o : ccxx)
    { killCC((CC) _o); }
  }

  public void killCC(CC ccxx)
  { ccs.remove(ccxx);
  }


  public static void main(String[] args)
  { CC xx = new CC(); 

    for (int i = 0; i < 100000; i++) 
	{ xx.addsq(i); }
	
	System.out.println(xx.getsq()); 
	
/*    for (int i = 100; i > 0; i--) 
	{ xx.op(i); }
	
	xx.op1(); 
	
	System.out.println(xx.getsq()); 
	
	xx.op2(); 
	
	System.out.println(xx.getsq()); */ 

    java.util.Date dd = new java.util.Date(); 
	long t1 = dd.getTime(); 
	  	
	for (int i = 0; i < 1000; i++)
	{ int y = xx.op3(); }
	
	// System.out.println(y); 
	
	java.util.Date d2 = new java.util.Date(); 
	long t2 = d2.getTime(); 
	System.out.println(">>> Time: " + (t2-t1)); 
  }

   
}


